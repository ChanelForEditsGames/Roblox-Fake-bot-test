[app]
title = Only Roblox Visualizer
package.name = visualizer
package.domain = org.onlyroblox
source.dir = .
source.include_exts = py,kv,xml,java,txt
version = 0.1
requirements = python3,kivy,pillow,pytesseract,pyjnius
orientation = portrait
fullscreen = 0

android.api = 35
android.minapi = 23
android.ndk = 27b
android.permissions = FOREGROUND_SERVICE,FOREGROUND_SERVICE_MEDIA_PROJECTION
android.add_src = src/android
android.extra_manifest_xml = extra_manifest.xml
android.extra_manifest_application_arguments = extra_manifest_application_arguments.xml
android.enable_androidx = True

[buildozer]
log_level = 2
warn_on_root = 1
